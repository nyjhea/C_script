#include <stdio.h>
#include <stdlib.h>

typedef struct market{
char nev[50];
char targy[25];
char marka[30];
char tipus[20];
char ar[25];
char telo[25];
char email[60];
int feltoltes_datuma;
}market;


int beolvas(market **t,int *h,char *fN);
int kiir(market *t, int h);
int megegyszer();
int lehetosegek();
void kilep(market *t, char *fN, int h);
int ujElado(market **t, int *h);
void masol(char *innen, char *ide);
int emailcheck(char *ecim);
int telocheck(char *tszam);
int evcheck(int ev, int honap, int nap);



int main(){
market *termek=NULL; int ujra, hosszusag=0; char fajl_nev[300];
printf("Üdvözöllek az internet legnagyobb kereskedelmi oldalan! \n");
while(ujra=beolvas(&termek, &hosszusag, fajl_nev))
{
if(ujra==2){return 0; }
}
while(1){
        switch(lehetosegek()){
        case 1: kiir(termek, hosszusag); break;
        case 2: while(ujElado(&termek, &hosszusag)); break;
        case 3: kilep(termek, fajl_nev, hosszusag); return 0;
        default: printf("1,2 es a 3 gomb megnyomasaval tudsz opciot valaszani!\n");
        }
}
}
int beolvas(market **t, int *h, char *fN)
{
char szamol; int i;
FILE *fp=NULL;
printf("Beolvasando fajl neve: "); scanf("%s", fN);
if(!(fp=fopen(fN, "r")))
{
printf("Nem sikerult megtalalnom a dokumentumot!\n");
if(megegyszer()){return 1; }else{printf("Program vege!"); return 2; }
}
while((szamol=fgetc(fp)) != EOF){
if(szamol=='\n'){(*h)++; }
}
if(!(*t=(market *)malloc(*h*sizeof(market))))
{
printf("Sajnos megtelt a memori!");
if(megegyszer()){return 1 ;}else{printf("Program vege!"); return 2; }
}
rewind(fp);
for(i=0;i<*h;i++)
{
fscanf(fp, "%s\t%s\t%s\t%s\t%s\t%d\t%s\t%d", (*t)[i].nev, (*t)[i].targy,(*t)[i].marka, (*t)[i].tipus, (*t)[i].ar, &(*t)[i].telo, (*t)[i].email, &(*t)[i].feltoltes_datuma);
}
fclose(fp);
printf("Beolvasas sikeresen megtortent!");
return 0;
}
int kiir(market *t, int h){
int i;
for(i=0;i<h;i++){
printf("Nev:%s Targy:%s Marka:%s Tipus:%s Ar:%s Teloszam:%s E-mailcim:%s Vetel:%d\n", t[i].nev, t[i].targy, t[i].marka, t[i].tipus, t[i].ar, t[i].telo, t[i].email, t[i].feltoltes_datuma);
}
    }

int megegyszer(){
char ujra;
printf("Szeretnel meg jatszani? (i/n)"); scanf(" %c", &ujra);
if(ujra=='i'){return 1; }else{return 0; }
}
int lehetosegek(){
int lehetoseg;
printf("\nValasszon az alabbi lehetosegek kozul!\n");
printf("\n1:Nyilvantartas megtekintese\n2:Uj elado regisztralas\n3:Elhagyom az online piacot\n");
printf("Altalam valasztott lehetoseg: "); scanf("%d",&lehetoseg);
system("clear");
return lehetoseg;
}
void kilep(market *t, char *fN, int h){
	FILE *fp = NULL; char save; int i;

	printf("Lehet, hogy az ugyfellista megvaltozott.\n");
	printf("Menti a valtozasokat? (i / n) ");
	scanf(" %c", &save);

	if(save == 'i'){
		fp = fopen(fN, "w");
		for(i = 0; i < h; i++)
		{
			fprintf(fp, "%-50s-%-25s-%-30s-%-20s-%-25s-%d-%-60s-%d", t[i].nev, t[i].targy, t[i].marka, t[i].tipus, t[i].ar, t[i].telo, t[i].email, t[i].feltoltes_datuma);
		}
		fflush(fp);
		fclose(fp);
	}

	free(t);

	printf("Program kilep. A viszont látásra\n");
}
int ujElado(market **t, int *h){
char emailcim[60], telefonszam[20], ujra; int ev, honap, nap;
printf("E-mail cim: "); scanf("%s", emailcim);
if(emailcheck(emailcim))
{
printf("HIBA: ervenytelen email cim.\n");
if(megegyszer()){ return 1; }else{ return 0; }
}

printf("Telefonszam: "); scanf("%s", telefonszam);
if(telocheck(telefonszam))
{
printf("HIBA! ervenytelen telefonszam.\n");
if(megegyszer()){ return 1; }else{ return 0; }
}
printf("Ev: \t"); scanf("%d", &ev);
printf("Honap: \t"); scanf("%d", &honap);
printf("Nap: \t"); scanf("%d", &nap);

    masol(emailcim, (*t)[*h-1].email);

	masol(telefonszam, (*t)[*h-1].telo);

	printf("Nev: "); scanf("%s", (*t)[*h-1].nev);

	printf("Eszköztipus: "); scanf("%s \n", &(*t)[*h-1].targy);
	printf("Márka: "); scanf("%s\n", &(*t)[*h-1].marka);
	printf("Modell: "); scanf("%s\n", &(*t)[*h-1].tipus);
	printf("Ar: "); scanf("%s\n", &(*t)[*h-1].ar);

return 0;
}
void masol(char *innen, char *ide){
	int i = 0;
	while(innen[i]){	ide[i] = innen[i]; i++;	}
	ide[i] = 0;
}

int emailcheck(char *ecim){
	int i = 0, dotIndex, atIndex, numberOfDots = -1, numberOfAts = -1, diff;

	while(ecim[i])
	{
		if(ecim[i] == '.'){	dotIndex = i; numberOfDots++;	}
		if(ecim[i] == '@'){	atIndex = i; numberOfAts++;	}
		i++;
	}

	if((diff = dotIndex - atIndex) < 0){ return 1; }
	if(numberOfDots || numberOfAts){ return 1; }
	if(!dotIndex || !atIndex || dotIndex == i-1 || atIndex == i-1 || diff == 1){ return 1; }


	return 0;
}
int telocheck(char *tszam){
	int i = 0;

	while(tszam[i])
	{
		if(tszam[i] < '0' ||	tszam[i] > '9'){	return 1;	}
		i++;
	}

	return 0;
}
